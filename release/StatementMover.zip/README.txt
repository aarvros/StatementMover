Getting Started:

1. Go to https://dotnet.microsoft.com/en-us/download/dotnet/thank-you/sdk-8.0.403-windows-x64-installer
2. The installer will be automatically downloaded to your downloads folder
3. Run the installer. The installer may ask you to enter admin credentials
4. Extract the zip file to a known location
5. Double click on the bin folder and locate the StatementMover.exe
6. Right click on the EXE and click create shortcut
7. Rename the shortcut to a name of your choosing
8. Move the shortcut to your desktop or another location where you would like to run the application from.
9. Double click on the shortcut you created to run the application